/*
 * TLS-Attacker - A Modular Penetration Testing Framework for TLS
 *
 * Copyright 2014-2023 Ruhr University Bochum, Paderborn University, Technology Innovation Institute, and Hackmanit GmbH
 *
 * Licensed under Apache License, Version 2.0
 * http://www.apache.org/licenses/LICENSE-2.0.txt
 */
package de.rub.nds.tlsattacker.tracetool.config;

import com.beust.jcommander.ParametersDelegate;
import de.rub.nds.tlsattacker.core.config.Config;
import de.rub.nds.tlsattacker.core.config.TLSDelegateConfig;
import de.rub.nds.tlsattacker.core.config.delegate.*;
import de.rub.nds.tlsattacker.core.workflow.factory.WorkflowTraceType;

public class TraceToolCommandConfig extends TLSDelegateConfig {

    public static final String COMMAND = "tracetool";

    @ParametersDelegate private ProtocolVersionDelegate protocolVersionDelegate;
    @ParametersDelegate private WorkflowTypeDelegate workflowTypeDelegate;
    @ParametersDelegate private FilterDelegate filterDelegate;
    @ParametersDelegate private ListDelegate listDelegate;
    @ParametersDelegate private RunningModeDelegate runningModeDelegate;
    @ParametersDelegate private CipherSuiteDelegate ciphersuiteDelegate;

    public TraceToolCommandConfig(GeneralDelegate delegate) {
        super(delegate);
        this.protocolVersionDelegate = new ProtocolVersionDelegate();
        this.workflowTypeDelegate = new WorkflowTypeDelegate();
        this.filterDelegate = new FilterDelegate();
        this.listDelegate = new ListDelegate();
        this.ciphersuiteDelegate = new CipherSuiteDelegate();
        this.runningModeDelegate = new RunningModeDelegate();
        addDelegate(protocolVersionDelegate);
        addDelegate(ciphersuiteDelegate);
        addDelegate(workflowTypeDelegate);
        addDelegate(filterDelegate);
        addDelegate(listDelegate);
        addDelegate(runningModeDelegate);
    }

    @Override
    public Config createConfig() {
        Config config = super.createConfig();

        if (config.getWorkflowTraceType() == null) {
            config.setWorkflowTraceType(WorkflowTraceType.HANDSHAKE);
        }
        return config;
    }
}
